<?php 

 ?>

<!DOCTYPE html>
<html lang="nl">
<head>
	<meta charset="UTF-8">
	<title>Lab 2</title>
</head>
<body>
	<h1>De ingevulde gegevens zijn: </h1>
	<p>Naam: <?php echo $_POST["fullName"]; ?></p>
	<p>Emailadres: <?php echo $_POST["email"]; ?></p>
</body>
</html>