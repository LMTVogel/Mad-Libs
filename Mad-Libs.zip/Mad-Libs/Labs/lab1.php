<?php 

 ?>

<!DOCTYPE html>
<html lang="nl">
<head>
	<meta charset="UTF-8">
	<title>Lab 1</title>
</head>
<body>
	<form action="welcome.php" method="post">
		Vul uw volledige naam in:<br>
		<input type="text" name="fullName">
		<br>
		Vul uw e-mail in:<br>
		<input type="email" name="email">
		<input type="submit">
	</form>
</body>
</html>